# Online Book Store Website

A Django-powered online bookstore with a clean, modern UI, user authentication, cart and checkout flow, and sample data loading.

## Setup

1. Activate the virtual environment:

```powershell
cd "D:\Praveen Main\Internship Report\Cybernaut\Flask\Online Book Store Website using Django"
.venv\Scripts\Activate.ps1
```

2. Install dependencies (if needed):

```powershell
pip install -r requirements.txt
```

3. Apply migrations:

```powershell
python manage.py migrate
```

4. Load sample data:

```powershell
python manage.py load_sample_data
```

5. Create a superuser for admin access:

```powershell
python manage.py createsuperuser
```

6. Run the development server:

```powershell
python manage.py runserver
```

Open `http://127.0.0.1:8000/` to view the bookstore.

## Admin guidance

- Visit `http://127.0.0.1:8000/admin/` and log in with the superuser account.
- To add a new category:
  - Click **Categories**.
  - Add a `Name` and a unique `Slug`.
  - Save the category.
- To add a new book:
  - Click **Books**.
  - Fill in `Title`, `Author`, `Category`, `Description`, `Price`, `Stock`, and `Slug`.
  - Mark `Available` if the book should be shown in the store.
  - Save the book.
- Orders are available under **Orders** once checkout is completed.

## Features

- Catalog page with category filters and search
- Book detail pages with "Add to cart"
- Session-based cart
- Checkout form and order confirmation
- User login / sign up / logout
- Order history for signed-in users
- Admin support for categories, books, and orders
