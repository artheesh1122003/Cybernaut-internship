from django.contrib import admin

from .models import Book, Category, FeaturedSection, Subscriber, Order, OrderItem


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug')
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'category', 'price', 'stock', 'available', 'is_bestseller', 'is_new_arrival', 'audio_available')
    list_filter = ('available', 'category', 'is_bestseller', 'is_new_arrival', 'audio_available')
    search_fields = ('title', 'author', 'description')
    prepopulated_fields = {'slug': ('title',)}


@admin.register(FeaturedSection)
class FeaturedSectionAdmin(admin.ModelAdmin):
    list_display = ('title', 'active', 'order')
    list_filter = ('active',)
    search_fields = ('title', 'description')
    prepopulated_fields = {'slug': ('title',)}
    filter_horizontal = ('books',)


@admin.register(Subscriber)
class SubscriberAdmin(admin.ModelAdmin):
    list_display = ('email', 'active', 'subscribed_at')
    list_filter = ('active', 'subscribed_at')
    search_fields = ('email',)
    readonly_fields = ('subscribed_at',)
    ordering = ('-subscribed_at',)


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    readonly_fields = ('book', 'price', 'quantity')
    extra = 0


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'first_name', 'last_name', 'email', 'created_at', 'updated_at')
    list_filter = ('created_at', 'city')
    search_fields = ('first_name', 'last_name', 'email', 'address')
    inlines = [OrderItemInline]
