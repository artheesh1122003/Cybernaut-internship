from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.views import LogoutView
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse_lazy
from django.views.generic import DetailView, FormView, ListView, TemplateView, View

from .forms import CheckoutForm, NewsletterSubscriptionForm, SignUpForm
from .models import Book, Category, FeaturedSection, Subscriber, Order, OrderItem
from .services import generate_book_summary


def _get_cart(session):
    return session.get('cart', {})


def _save_cart(session, cart):
    session['cart'] = cart
    session.modified = True


def _build_cart_items(session):
    raw_cart = _get_cart(session)
    book_ids = [int(book_id) for book_id in raw_cart.keys() if book_id.isdigit()]
    books = Book.objects.filter(pk__in=book_ids)
    items = []
    total = 0

    for book in books:
        quantity = raw_cart.get(str(book.pk), 0)
        subtotal = book.price * quantity
        items.append({'book': book, 'quantity': quantity, 'subtotal': subtotal})
        total += subtotal

    return items, total


class SignUpView(FormView):
    template_name = 'register.html'
    form_class = SignUpForm
    success_url = reverse_lazy('store:book_list')

    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        messages.success(self.request, 'Welcome! Your account has been created.')
        return super().form_valid(form)


class NewsletterSubscribeView(View):
    def post(self, request, *args, **kwargs):
        form = NewsletterSubscriptionForm(request.POST)
        if form.is_valid():
            subscriber, created = Subscriber.objects.get_or_create(
                email=form.cleaned_data['email'],
                defaults={'active': True}
            )
            if created:
                messages.success(request, 'Thanks! You are now subscribed to our newsletter.')
            else:
                if not subscriber.active:
                    subscriber.active = True
                    subscriber.save()
                messages.info(request, 'You are already subscribed to our newsletter.')
        else:
            messages.error(request, 'Please enter a valid email address to subscribe.')
        return redirect(request.META.get('HTTP_REFERER', 'store:book_list'))


class BookListView(ListView):
    model = Book
    template_name = 'store/book_list.html'
    context_object_name = 'books'
    paginate_by = 12

    def get_queryset(self):
        query = self.request.GET.get('q', '')
        category_slug = self.request.GET.get('category', '') or self.kwargs.get('category', '')
        queryset = Book.objects.filter(available=True)

        if category_slug:
            queryset = queryset.filter(category__slug=category_slug)

        if query:
            queryset = queryset.filter(
                Q(title__icontains=query)
                | Q(author__icontains=query)
                | Q(description__icontains=query)
                | Q(category__name__icontains=query)
            )

        return queryset.order_by('-created_at')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        query = self.request.GET.get('q', '')
        category_slug = self.request.GET.get('category', '') or self.kwargs.get('category', '')
        selected_category = Category.objects.filter(slug=category_slug).first() if category_slug else None

        context['categories'] = Category.objects.order_by('name')
        context['selected_category'] = category_slug
        context['selected_category_obj'] = selected_category
        context['search_query'] = query
        context['show_homepage_panels'] = not category_slug and not query

        if context['show_homepage_panels']:
            context['newsletter_form'] = NewsletterSubscriptionForm()
            context['featured_books'] = Book.objects.filter(available=True, is_bestseller=False).order_by('-created_at')[:4]
            context['featured_sections'] = FeaturedSection.objects.filter(active=True).prefetch_related('books')
            context['bestseller_books'] = Book.objects.filter(available=True, is_bestseller=True).order_by('-created_at')[:4]
            context['new_arrival_books'] = Book.objects.filter(available=True, is_new_arrival=True).order_by('-created_at')[:4]
            context['audio_books'] = Book.objects.filter(available=True, audio_available=True).order_by('-created_at')[:4]
            context['homepage_categories'] = [
                {
                    'category': category,
                    'books': category.books.filter(available=True).order_by('-created_at')[:5]
                }
                for category in context['categories']
            ]
        else:
            context['newsletter_form'] = NewsletterSubscriptionForm()
            context['featured_books'] = []
            context['featured_sections'] = []
            context['bestseller_books'] = []
            context['new_arrival_books'] = []
            context['audio_books'] = []
            context['homepage_categories'] = []

        if selected_category:
            context['page_heading'] = f"{selected_category.name} Books"
            context['page_description'] = f"Discover new and popular titles from {selected_category.name}."
        elif query:
            context['page_heading'] = 'Search results'
            context['page_description'] = f"Results for “{query}”. Find the books that match your search."
        else:
            context['page_heading'] = 'Featured books'
            context['page_description'] = 'Shop the latest additions and popular titles in our bookstore.'

        return context


class BookDetailView(DetailView):
    model = Book
    template_name = 'store/book_detail.html'
    context_object_name = 'book'
    slug_field = 'slug'
    slug_url_kwarg = 'slug'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        book = self.get_object()
        ai_summary = book.ai_summary.strip()
        if not ai_summary:
            ai_summary = generate_book_summary(book.title, book.author, book.description)
            if ai_summary:
                book.ai_summary = ai_summary
                book.save(update_fields=['ai_summary'])
        context['ai_summary'] = ai_summary or "A short AI-powered summary will appear here once available."
        return context


class CartView(TemplateView):
    template_name = 'store/cart.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        items, total = _build_cart_items(self.request.session)
        context['cart_items'] = items
        context['cart_total'] = total
        return context


class CartAddView(View):
    def get(self, request, book_id):
        book = get_object_or_404(Book, pk=book_id, available=True)
        cart = _get_cart(request.session)
        cart[str(book.pk)] = cart.get(str(book.pk), 0) + 1
        _save_cart(request.session, cart)
        messages.success(request, f'"{book.title}" added to your cart.')
        return redirect(request.META.get('HTTP_REFERER', 'store:book_list'))


class CartRemoveView(View):
    def get(self, request, book_id):
        cart = _get_cart(request.session)
        if str(book_id) in cart:
            del cart[str(book_id)]
            _save_cart(request.session, cart)
            messages.success(request, 'Item removed from your cart.')
        return redirect('store:cart')


class CheckoutView(FormView):
    template_name = 'store/checkout.html'
    form_class = CheckoutForm

    def dispatch(self, request, *args, **kwargs):
        cart_items, _ = _build_cart_items(request.session)
        if not cart_items:
            messages.warning(request, 'Your cart is empty. Add books before checkout.')
            return redirect('store:book_list')
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        items, total = _build_cart_items(self.request.session)
        context['cart_items'] = items
        context['cart_total'] = total
        return context

    def form_valid(self, form):
        order = Order.objects.create(
            user=self.request.user if self.request.user.is_authenticated else None,
            first_name=form.cleaned_data['first_name'],
            last_name=form.cleaned_data['last_name'],
            email=form.cleaned_data['email'],
            address=form.cleaned_data['address'],
            city=form.cleaned_data['city'],
            postal_code=form.cleaned_data['postal_code'],
        )
        cart_items, _ = _build_cart_items(self.request.session)
        for item in cart_items:
            OrderItem.objects.create(
                order=order,
                book=item['book'],
                price=item['book'].price,
                quantity=item['quantity'],
            )
        self.request.session['cart'] = {}
        self.request.session['last_order_id'] = order.id
        messages.success(self.request, 'Your order has been placed successfully.')
        return redirect('store:order_complete', pk=order.pk)


class OrderCompleteView(DetailView):
    model = Order
    template_name = 'store/order_complete.html'
    context_object_name = 'order'

    def get_queryset(self):
        queryset = super().get_queryset().prefetch_related('items__book')
        if self.request.user.is_authenticated:
            return queryset.filter(user=self.request.user)

        last_order_id = self.request.session.get('last_order_id')
        if last_order_id == self.kwargs.get('pk'):
            return queryset

        return queryset.none()


class OrderListView(LoginRequiredMixin, ListView):
    model = Order
    template_name = 'store/order_list.html'
    context_object_name = 'orders'
    paginate_by = 10

    def get_queryset(self):
        return Order.objects.filter(user=self.request.user).order_by('-created_at')
