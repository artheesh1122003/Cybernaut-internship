from django.contrib.auth import views as auth_views
from django.urls import path

from .views import (
    BookDetailView,
    BookListView,
    CartAddView,
    CartRemoveView,
    CartView,
    CheckoutView,
    NewsletterSubscribeView,
    OrderCompleteView,
    OrderListView,
    SignUpView,
)

app_name = 'store'

urlpatterns = [
    path('', BookListView.as_view(), name='book_list'),
    path('category/<slug:category>/', BookListView.as_view(), name='book_category'),
    path('book/<slug:slug>/', BookDetailView.as_view(), name='book_detail'),
    path('cart/', CartView.as_view(), name='cart'),
    path('cart/add/<int:book_id>/', CartAddView.as_view(), name='cart_add'),
    path('cart/remove/<int:book_id>/', CartRemoveView.as_view(), name='cart_remove'),
    path('checkout/', CheckoutView.as_view(), name='checkout'),
    path('subscribe/', NewsletterSubscribeView.as_view(), name='newsletter_subscribe'),
    path('orders/', OrderListView.as_view(), name='order_list'),
    path('order/success/<int:pk>/', OrderCompleteView.as_view(), name='order_complete'),
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('register/', SignUpView.as_view(), name='register'),
]
