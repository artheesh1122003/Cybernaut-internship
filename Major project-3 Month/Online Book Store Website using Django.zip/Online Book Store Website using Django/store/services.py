import json
import os
import urllib.error
import urllib.request

GEMINI_API_KEY = os.getenv('GOOGLE_GEMINI_API_KEY', '').strip()
GEMINI_MODEL = os.getenv('GOOGLE_GEMINI_MODEL', 'gemini-1.5-pro')
GEMINI_TIMEOUT = int(os.getenv('GOOGLE_GEMINI_TIMEOUT', '15'))


def generate_book_summary(title: str, author: str, description: str) -> str:
    if not GEMINI_API_KEY:
        return ''

    prompt = [
        {
            'role': 'system',
            'content': 'You are a helpful book summary assistant.'
        },
        {
            'role': 'user',
            'content': (
                f'Write a short, engaging overview for the book titled "{title}"'
                + (f' by {author}' if author else '')
                + (f'. Use this description as context: {description}' if description else '')
                + ' Keep it under 120 words.'
            )
        }
    ]

    api_endpoint = f'https://gemini.googleapis.com/v1/models/{GEMINI_MODEL}:generate'
    headers = {
        'Content-Type': 'application/json',
    }

    request_url = api_endpoint
    if GEMINI_API_KEY.startswith('AIza'):
        request_url = f'{api_endpoint}?key={GEMINI_API_KEY}'
    else:
        headers['Authorization'] = f'Bearer {GEMINI_API_KEY}'

    payload = {
        'temperature': 0.55,
        'maxOutputTokens': 220,
        'candidateCount': 1,
        'prompt': {
            'messages': prompt,
        },
    }

    request = urllib.request.Request(
        request_url,
        data=json.dumps(payload).encode('utf-8'),
        headers=headers,
        method='POST',
    )

    try:
        with urllib.request.urlopen(request, timeout=GEMINI_TIMEOUT) as response:
            result = json.loads(response.read().decode('utf-8'))
            candidate = result.get('candidates', [{}])[0]
            return candidate.get('output', '').strip()
    except (urllib.error.HTTPError, urllib.error.URLError, json.JSONDecodeError):
        return ''
